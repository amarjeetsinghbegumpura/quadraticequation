package com.td.interview.excercise.quadraticequation.entity;

public enum ResultType {
    REAL_AND_DISTINCT,
    REAL_AND_EQUAL,
    COMPLEX_AND_DISTINCT
}
