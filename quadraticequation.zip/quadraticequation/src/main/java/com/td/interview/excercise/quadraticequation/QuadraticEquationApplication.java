package com.td.interview.excercise.quadraticequation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class QuadraticEquationApplication {

	public static void main(String[] args) {
		SpringApplication.run(QuadraticEquationApplication.class, args);
	}

}
